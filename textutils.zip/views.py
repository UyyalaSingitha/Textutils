from django.http import HttpResponse
from django.shortcuts import render


def index(request):
    return render(request, 'index.html')


def analyze(request):
    djtext = request.POST.get('text', 'default')

    removepunc = request.POST.get('removepunc', 'off')
    fullcaps = request.POST.get('fullcaps', 'off')
    newlineremover = request.POST.get('newlineremover', 'off')
    extraspaceremover = request.POST.get('extraspaceremover', 'off')
    charactercount = request.POST.get('charactercount', 'off')

    if removepunc == "on":
        punctuations = '''!(){}_-;:'"\/,.<>?@#$%^&*~'''
        analyzed = ""
        for char in djtext:
            if char not in punctuations:
                analyzed = analyzed + char

        params = {'purpose': 'Removed Punctuations', 'Analyzed_text': analyzed}
        djtext = analyzed

    if (fullcaps == "on"):
        analyzed = ""

        for char in djtext:
            analyzed += char.upper()
        params = {'purpose': 'change to uppercase', 'Analyzed_text': analyzed}
        djtext = analyzed

    if (newlineremover == "on"):
        analyzed = ""

        for char in djtext:
            if char != "\n" and char != "\r":
                analyzed += char

        params = {'purpose': 'Removed newlines', 'Analyzed_text': analyzed}
        djtext = analyzed

    if (extraspaceremover == "on"):
        analyzed = ""

        for index, char in enumerate(djtext):
            if not (djtext[index] == " " and djtext[index + 1] == " "):
                analyzed += char

        params = {'purpose': 'Removed newlines', 'Analyzed_text': analyzed}
        djtext = analyzed


    if (charactercount == "on"):
        count = int(0)
        analyzed = ""

        for char in djtext:
            count += 1

        params = {'purpose': 'Characters counted', 'Analyzed_text': count}



    if (removepunc != "on" and newlineremover != "on" and extraspaceremover != "on" and fullcaps != "on" and charactercount != "on"):
        return HttpResponse("Please Select any operation and try again")

    return render(request, 'analyze.html', params)
